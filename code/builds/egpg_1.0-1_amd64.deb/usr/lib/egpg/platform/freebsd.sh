GETOPT="/usr/local/bin/getopt"
SHRED="rm -P -f"
